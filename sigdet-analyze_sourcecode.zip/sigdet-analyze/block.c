#include <limits.h>

#include "sigdet.h"
#include "file.h"
#include "session.h"
#include "block.h"

block_t *init_block(block_t *bl, session_t *sess, char *name, size_t start,
    size_t len)
{
    strncpy(bl->name, name, sizeof bl->name);
    bl->session = sess;
    bl->trials = sess->trials + start;
    bl->len = len;
    bl->start_s = start + 1;
    bl->end_s = start + len;
    bl->stats = init_stats(bl);

    return bl;
}

block_t *add_block(session_t *sess, char *name, size_t start, size_t len)
{
    sess->blocks = realloc(sess->blocks, ++sess->n_bl * sizeof *sess->blocks);
    return init_block(&sess->blocks[sess->n_bl-1], sess, name, start, len);
}

block_t *alloc_block(session_t *sess, char *name, size_t start, size_t len)
{
    block_t *bl = malloc(sizeof *bl);
    return init_block(bl, sess, name, start, len);
}

struct block_stats *init_stats(block_t *bl)
{
    struct block_stats *self;
    int i, total;
    int r_correct, r_incorrect, l_correct, l_incorrect;
    int total_time, total_r_time, total_l_time;
    double diff = 0, x1, y1, x2, y2, x3, y3;

    self = malloc(sizeof *self);
    self->n_valid = 0;
    self->n_rich = 0;
    self->n_lean = 0;
    self->n_correct = 0;
    self->n_r_correct = 0;
    self->n_l_correct = 0;
    self->avg_time = 0;
    self->r_avg_time = 0;
    self->l_avg_time = 0;
    self->min_time = INT_MAX;
    self->max_time = 0;
    self->std_dev_time = 0;
    self->n_rewards = 0;
    self->n_r_rewards = 0;
    self->n_l_rewards = 0;
    self->accuracy = 0;
    self->r_accuracy = 0;
    self->l_accuracy = 0;
    self->sensitivity1 = 0;
    self->sensitivity2 = 0;
    self->sensitivity3 = 0;
    self->discrim1 = 0;
    self->discrim2 = 0;
    self->discrim3 = 0;
    self->n_above_thresh = 0;
    self->n_below_thresh = 0;
    self->n_total_out = 0;
    self->n_out_stdev = 0;
    self->n_total_out = 0;

    for (i = 0; i < bl->len; i++) {
        if (!bl->trials[i].out) {
            self->n_valid++;
            if (is_rich(bl->session, bl->trials[i]))
                self->n_rich++;
            if (is_lean(bl->session, bl->trials[i]))
                self->n_lean++;
            if (bl->trials[i].correct) {
                self->n_correct++;
                if (is_rich(bl->session, bl->trials[i]))
                    self->n_r_correct++;
                if (is_lean(bl->session, bl->trials[i]))
                    self->n_l_correct++;
            }
            if (bl->trials[i].feedback) {
                self->n_rewards++;
                if (is_rich(bl->session, bl->trials[i]))
                    self->n_r_rewards++;
                if (is_lean(bl->session, bl->trials[i]))
                    self->n_l_rewards++;
            }
            if (bl->trials[i].rt < self->min_time)
                self->min_time = bl->trials[i].rt;
            if (bl->trials[i].rt > self->max_time)
                self->max_time = bl->trials[i].rt;
        } else {
            self->n_total_out++;
            if (bl->trials[i].out == OUT_ABOVE)
                self->n_above_thresh++;
            else if (bl->trials[i].out == OUT_BELOW)
                self->n_below_thresh++;
            else if (bl->trials[i].out == OUT_STDEV)
                self->n_out_stdev++;
        }
    }

    total = bl->len;
    x1 = 0;
    y1 = 0;
    x2 = 0;
    y2 = 0;
    x3 = 0;
    y3 = 0;
    total_time = 0;
    total_r_time = 0;
    total_l_time = 0;

    self->accuracy = (float) self->n_correct / self->n_valid;
    self->r_accuracy = (float) self->n_r_correct / self->n_rich;
    self->l_accuracy = (float) self->n_l_correct / self->n_lean;

    for (i = 0; i < bl->len; i++) {
        if (!bl->trials[i].out) {
            total_time += bl->trials[i].rt;
            if (is_rich(bl->session, bl->trials[i]))
                total_r_time += bl->trials[i].rt;
            if (is_lean(bl->session, bl->trials[i]))
                total_l_time += bl->trials[i].rt;
        }
    }

    self->avg_time = (float) total_time / self->n_valid;
    self->r_avg_time = (float) total_r_time / self->n_rich;
    self->l_avg_time = (float) total_l_time / self->n_lean;

    for (i = 0; i < bl->len; i++)
        if (!bl->trials[i].out)
            diff += pow(bl->trials[i].rt - self->avg_time, 2);
    if (bl->len > 1)
        self->std_dev_time = sqrt(diff / (bl->len - 1));

    /* sens */

    r_correct = self->n_r_correct;
    r_incorrect = self->n_rich - self->n_r_correct;
    l_correct = self->n_l_correct;
    l_incorrect = self->n_lean - self->n_l_correct;

    x1 = r_correct * l_incorrect;
    y1 = r_incorrect * l_correct;

    x2 = (r_correct + 0.5) * (l_incorrect + 0.5);
    y2 = (r_incorrect + 0.5) * (l_correct + 0.5);

    if (r_correct == 0) r_correct = 1;
    if (l_correct == 0) l_correct = 1;
    if (l_incorrect == 0) l_incorrect = 1;
    if (r_incorrect == 0) r_incorrect = 1;
    x3 = r_correct * l_incorrect;
    y3 = r_incorrect * l_correct;

    self->sensitivity1 = log10(x1 / y1) / 2;
    self->sensitivity2 = log10(x2 / y2) / 2;
    self->sensitivity3 = log10(x3 / y3) / 2;

    /* discrim */

    r_correct = self->n_r_correct;
    r_incorrect = self->n_rich - self->n_r_correct;
    l_correct = self->n_l_correct;
    l_incorrect = self->n_lean - self->n_l_correct;

    x1 = self->n_r_correct * self->n_l_correct;
    y1 = r_incorrect * l_incorrect;

    x2 = (self->n_r_correct + 0.5) * (self->n_l_correct + 0.5);
    y2 = (r_incorrect + 0.5) * (l_incorrect + 0.5);

    if (self->n_r_correct == 0) r_correct = 1;
    if (self->n_l_correct == 0) l_correct = 1;
    if (r_incorrect == 0) r_incorrect = 1;
    if (l_incorrect == 0) l_incorrect = 1;
    x3 = r_correct * l_correct;
    y3 = r_incorrect * l_incorrect;

    self->discrim1 = log10(x1 / y1) / 2;
    self->discrim2 = log10(x2 / y2) / 2;
    self->discrim3 = log10(x3 / y3) / 2;

    return self;
}

void write_block_stats(block_t *bl, FILE *out)
{
    /* must keep this in line with file.c... */
    fprintf(out, "%d\t", bl->start_s);
    fprintf(out, "%d\t", bl->end_s);
    fprintf(out, "%d\t", bl->stats->n_valid);
    fprintf(out, "%d\t", bl->stats->n_rich);
    fprintf(out, "%d\t", bl->stats->n_lean);
    fprintf(out, "%d\t", bl->stats->n_correct);
    fprintf(out, "%d\t", bl->stats->n_r_correct);
    fprintf(out, "%d\t", bl->stats->n_l_correct);
    fprintf(out, "%d\t", bl->stats->n_rewards);
    fprintf(out, "%d\t", bl->stats->n_r_rewards);
    fprintf(out, "%d\t", bl->stats->n_l_rewards);
    fprintf(out, "%d\t", bl->stats->n_below_thresh);
    fprintf(out, "%d\t", bl->stats->n_above_thresh);
    fprintf(out, "%d\t", bl->stats->n_out_stdev);
    fprintf(out, "%d\t", bl->stats->n_total_out);
    fprintf(out, "%f\t", bl->stats->avg_time);
    fprintf(out, "%f\t", bl->stats->r_avg_time);
    fprintf(out, "%f\t", bl->stats->l_avg_time);
    fprintf(out, "%d\t", bl->stats->min_time);
    fprintf(out, "%d\t", bl->stats->max_time);
    fprintf(out, "%f\t", bl->stats->std_dev_time);
    fprintf(out, "%f\t", bl->stats->accuracy);
    fprintf(out, "%f\t", bl->stats->r_accuracy);
    fprintf(out, "%f\t", bl->stats->l_accuracy);
    fprintf(out, "%lf\t", bl->stats->sensitivity1);
    fprintf(out, "%lf\t", bl->stats->sensitivity3);
    fprintf(out, "%lf\t", bl->stats->sensitivity2);
    fprintf(out, "%lf\t", bl->stats->discrim1);
    fprintf(out, "%lf\t", bl->stats->discrim3);
    fprintf(out, "%lf\t", bl->stats->discrim2);
}

void write_block_quick(block_t *bl, FILE *out)
{
    fprintf(out, "%f\t", bl->stats->avg_time);
    fprintf(out, "%f\t", bl->stats->r_avg_time);
    fprintf(out, "%f\t", bl->stats->l_avg_time);
    fprintf(out, "%f\t", bl->stats->accuracy);
    fprintf(out, "%f\t", bl->stats->r_accuracy);
    fprintf(out, "%f\t", bl->stats->l_accuracy);
    fprintf(out, "%lf\t", bl->stats->sensitivity1);
    fprintf(out, "%lf\t", bl->stats->sensitivity3);
    fprintf(out, "%lf\t", bl->stats->sensitivity2);
    fprintf(out, "%lf\t", bl->stats->discrim1);
    fprintf(out, "%lf\t", bl->stats->discrim3);
    fprintf(out, "%lf\n", bl->stats->discrim2);
}

void write_block_summary(block_t *bl, FILE *out)
{
    fprintf(out, "\n---------- Block %s (trials %d-%d) -------\n",
        bl->name, bl->start_s, bl->end_s);

    /*fprintf(out, "short key: %c\n", bl->session.s_key); */
    /*fprintf(out, "long key: %c\n", bl->session.l_key); */
    fprintf(out, "valid trials: %d\n", bl->stats->n_valid);
    fprintf(out, "\trich: %d\n", bl->stats->n_rich);
    fprintf(out, "\tlean: %d\n", bl->stats->n_lean);
    fprintf(out, "total correct: %d\n", bl->stats->n_correct);
    fprintf(out, "\trich: %d\n", bl->stats->n_r_correct);
    fprintf(out, "\tlean: %d\n", bl->stats->n_l_correct);
    fprintf(out, "total rewards: %d\n", bl->stats->n_rewards);
    fprintf(out, "\trich: %d\n", bl->stats->n_r_rewards);
    fprintf(out, "\tlean: %d\n", bl->stats->n_l_rewards);
    fprintf(out, "total out: %d\n", bl->stats->n_total_out);
    fprintf(out, "\tbelow thresh: %d\n", bl->stats->n_below_thresh);
    fprintf(out, "\tabove thresh: %d\n", bl->stats->n_above_thresh);
    fprintf(out, "\t3 stdevs outliers: %d\n", bl->stats->n_out_stdev);
    fprintf(out, "mean response time: %f\n", bl->stats->avg_time);
    fprintf(out, "\trich: %f\n", bl->stats->r_avg_time);
    fprintf(out, "\tlean: %f\n", bl->stats->l_avg_time);
    fprintf(out, "min time: %d\n", bl->stats->min_time);
    fprintf(out, "max time: %d\n", bl->stats->max_time);
    fprintf(out, "std dev time: %f\n", bl->stats->std_dev_time);
    fprintf(out, "overall accuracy: %f\n", bl->stats->accuracy);
    fprintf(out, "\trich: %f\n", bl->stats->r_accuracy);
    fprintf(out, "\tlean: %f\n", bl->stats->l_accuracy);
    fprintf(out, "RB_pure: %lf\n", bl->stats->sensitivity1);
    fprintf(out, "RB_adjst_zeros: %lf\n", bl->stats->sensitivity3);
    fprintf(out, "RB_adjst_all: %lf\n", bl->stats->sensitivity2);
    fprintf(out, "dis_pure: %lf\n", bl->stats->discrim1);
    fprintf(out, "dis_adjst_zeros: %lf\n", bl->stats->discrim3);
    fprintf(out, "dis_adjst_all: %lf\n", bl->stats->discrim2);
}

void write_rev_summary(block_t *bl, FILE *out)
{
    fprintf(out, "\nREVERSED:\n");
    fprintf(out, "overall accuracy: %f\n", bl->stats->accuracy);
    fprintf(out, "\trich: %f\n", bl->stats->r_accuracy);
    fprintf(out, "\tlean: %f\n", bl->stats->l_accuracy);
    fprintf(out, "RB_pure: %lf\n", bl->stats->sensitivity1);
    fprintf(out, "RB_adjst_zeros: %lf\n", bl->stats->sensitivity3);
    fprintf(out, "RB_adjst_all: %lf\n", bl->stats->sensitivity2);
    fprintf(out, "dis_pure: %lf\n", bl->stats->discrim1);
    fprintf(out, "dis_adjst_zeros: %lf\n", bl->stats->discrim3);
    fprintf(out, "dis_adjst_all: %lf\n", bl->stats->discrim2);
}
