#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>

#ifndef SIGDET_H
#define SIGDET_H

#define TRIALS_MAX 1024
#define BUF_SMALL 16
#define BUF_MAX 8192

#define DEFAULT_BLOCKS 3
#define DEFAULT_TRIALS 300

#define DEFAULT_LO_THRESH 150
#define DEFAULT_HI_THRESH 2500

enum header {
    HEAD_PSYSCOPE,
    HEAD_DCRP,
    HEAD_FT,
    HEAD_B2R,
    HEAD_REWGEO,
    HEAD_UNKNOWN
};

enum stimulus {
    SHORT,
    LONG,
    BIG,
    LITTLE,
    UNKNOWN
};

enum outlier {
    NOT_OUT = 0,
    OUT_ABOVE,
    OUT_BELOW,
    OUT_STDEV
};

#define BIAS_TO_S(b) ( \
    b == SHORT ? "short" : \
    b == LONG ? "long" : \
    b == BIG ? "big" : \
    b == LITTLE ? "little" : \
    "unknown" )

struct block_stats {
    int n_valid;
    int n_rich;
    int n_lean;
    int n_correct;
    int n_r_correct;
    int n_l_correct;
    double avg_time;
    double r_avg_time;
    double l_avg_time;
    int min_time;
    int max_time;
    double std_dev_time;
    int n_rewards;
    int n_r_rewards;
    int n_l_rewards;
    double accuracy;
    double r_accuracy;
    double l_accuracy;
    double sensitivity1;
    double sensitivity2;
    double sensitivity3;
    double discrim1;
    double discrim2;
    double discrim3;
    int n_above_thresh;
    int n_below_thresh;
    int n_out_stdev;
    int n_total_out;
    double rev_r_accuracy;
    double rev_l_accuracy;
    double rev_sensitivity1;
    double rev_sensitivity2;
    double rev_sensitivity3;
    double rev_discrim1;
    double rev_discrim2;
    double rev_discrim3;
};

typedef struct {
    char outdir[1024];
    char indir[1024];
    int help;
    int overwrite;
    int split;
    int do_reverse;
    int n_bl;
    int blen;
    int sens_blen;
    int sens_start_trial;
    int prob_start_trial;
    int time;
    int version;
    int skip;
    enum header header_type;
    int lo_thresh;
    int hi_thresh;
} ArgRec;

struct trial;
struct block;
struct session;

typedef struct trial trial_t;
typedef struct block block_t;
typedef struct session session_t;

struct trial {
    int n;
    char stimulus[BUF_SMALL], tasktype[BUF_SMALL], key;
    int rt, correct, feedback;
    int due, due_rich, due_lean;
    enum outlier out;
};

struct block {
    char name[BUF_SMALL];
    session_t *session;
    trial_t *trials;
    size_t len;
    struct block_stats *stats;
    int start_s, end_s;
};

struct session {
    enum header head_type;
    char subj[BUF_SMALL];
    char date[BUF_SMALL];
    char time[BUF_SMALL];
    enum stimulus bias;
    char rich_name[BUF_SMALL];
    char lean_name[BUF_SMALL];
    char r_key, l_key;
    int lo_thresh;
    int hi_thresh;
    //int (*is_rich)(trial_t), (*is_lean)(trial_t);
    trial_t *trials;
    size_t len;
    block_t *blocks;
    size_t n_bl;
    size_t blen;
    int n_real_bl;
};

#endif /* SIGDET_H */
