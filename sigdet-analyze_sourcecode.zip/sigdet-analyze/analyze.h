#ifndef ANALYZE_H
#define ANALYZE_H

/* analyze.c */
int main(int argc, char *argv[]);
int getArgs(int count, char *argv[], ArgRec *args);

#endif /* ANALYZE_H */
