#include "sigdet.h"

#ifndef BLOCK_H
#define BLOCK_H

/* block.c */
block_t *init_block(block_t *bl, session_t *sess, char *name, size_t start, size_t len);
block_t *add_block(session_t *sess, char *name, size_t start, size_t len);
block_t *alloc_block(session_t *sess, char *name, size_t start, size_t len);
struct block_stats *init_stats(block_t *bl);
void write_block_stats(block_t *bl, FILE *out);
void write_block_quick(block_t *bl, FILE *out);
void write_block_summary(block_t *bl, FILE *out);
void write_rev_summary(block_t *bl, FILE *out);

#endif /* BLOCK_H */
