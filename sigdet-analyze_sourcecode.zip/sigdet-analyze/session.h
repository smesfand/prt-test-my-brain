#ifndef SESSION_H
#define SESSION_H

/* session.c */
session_t *alloc_session(trial_t *trials, size_t len, size_t n_bl, size_t blen, char *subj, char *date, char *time, char *b2r, int lo_thresh, int hi_thresh);
void init_bias(session_t *sess);
void init_bias_b2r(session_t *sess, const char *b2r);
void flag_outliers(session_t *sess);
int is_rich(session_t *sess, trial_t t);
int is_lean(session_t *sess, trial_t t);
void write_column_head(session_t *sess, FILE *out);
void write_trials(session_t *sess, FILE *out);
void write_preamble(session_t *sess, FILE *out);
void write_calcs_head(session_t *sess, FILE *out);
void write_outliers(session_t *sess, FILE *out);
void write_over_prob(session_t *sess, size_t start, size_t len, FILE *out);
void write_sens(session_t *sess, size_t start, size_t len, size_t chunk, int cumulative, FILE *out, char *over_path);

#endif /* SESSION_H */
