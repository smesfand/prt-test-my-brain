#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h>

#include "sigdet.h"
#include "file.h"
#include "session.h"
#include "block.h"

FILE *open_file(char *path, int overwrite)
{
    FILE *fd;

    if ((fd = fopen(path, overwrite ? "w+" : "a+"))) {
        return fd;
    } else {
        fprintf(stderr, "Could not open %s\n", path);
        exit(8);
    }
}

int read_file(const char *filename, size_t *length, char **buffer)
{
    int fd;
    struct stat file_info;

    /* Open the file. */
    fd = open(filename, O_RDONLY);
    /* Get information about the file. */
    fstat(fd, &file_info);
    *length = file_info.st_size;
    /* Make sure the file is an ordinary file. */
    if (!S_ISREG(file_info.st_mode)) {
        /* It's not, so give up. */
        close(fd);
        return -1;
    }

    /* Allocate a buffer large enough to hold the file's contents. */
    *buffer = (char *) malloc(*length);
    /* Read the file into the buffer. */
    read(fd, *buffer, *length);

    /* Finish up. */
    close(fd);
    return 0;
}

int skip_line(char *buffer, int offset)
{
    while (buffer[offset] != '\n' && buffer[offset] != '\0')
        offset++;

    return (offset + 1);
}

int read_line(char *buffer, int offset, char *line)
{
    int line_offset = 0;
    while (buffer[offset] != '\n' && buffer[offset] != '\0') {
        line[line_offset] = buffer[offset];
        offset++;
        line_offset++;
    }
    //offset++;
    line[line_offset] = '\0';
    return (offset);
}

enum header identify_header(char *buffer)
{
    int offset = 0, ii;
    char input_line[4096];
    enum header type;

    for (ii = 0; ii < 17; ii++) {
        offset = read_line(buffer, offset, input_line);
        type = identify_header_line(input_line);
        if (type != HEAD_UNKNOWN)
            break;
        else
            offset++;
    }
    return type;
}

enum header identify_header_line(char *s)
{
    if (strstr(s, "PsyScope")) {
        return HEAD_PSYSCOPE;
    } else if (strstr(s, "DCRP")) {
        return HEAD_DCRP;
    } else if (strstr(s, "FT")) {
        return HEAD_DCRP;
    } else if (strstr(s, "Block2Run")) {
        return HEAD_B2R;
    } else if (strstr(s, "tasktype")) {
        return HEAD_REWGEO;
    } else {
        return HEAD_UNKNOWN;
    }
}

int skip_lines(int num, char *buffer)
{
    int ii;
    int place = 0;

    for (ii = 0; ii < num; ii++) {
        place = skip_line(buffer, place);
    }
    return (place);
}

enum stimulus get_stim_type(const char *s)
{
    if (strcasecmp(s, "long") == 0) return LONG;
    else if (strcasecmp(s, "short") == 0) return SHORT;
    else if (strcasecmp(s, "big") == 0) return BIG;
    else if (strcasecmp(s, "little") == 0) return LITTLE;
    else return UNKNOWN;
}

void get_bias_name(enum stimulus bias, char *bias_name)
{
    if (bias == SHORT)
        strcpy(bias_name, "short");
    else if (bias == LONG)
        strcpy(bias_name, "long");
    else
        strcpy(bias_name, "none");

}

void print_bias(enum stimulus bias, FILE *outf)
{
    if (bias == SHORT)
        fprintf(outf, "Bias: short\n");
    else if (bias == LONG)
        fprintf(outf, "Bias: long\n");
    else
        fprintf(outf, "Bias: none\n");
}

void get_timedate(char *buffer, char *date, char *time)
{
    int offset;
    char input_line[4096];
    char trash[25];

    date[0] = '\0';
    offset = skip_lines(1, buffer);
    offset = read_line(buffer, offset, input_line);
    sscanf(input_line, "%s %s %s", date, time, trash);
}

void change_ext(char *buf, size_t len, const char *old, const char *new)
{
    char *p = rindex(buf, '.');
    size_t new_len;

    if (!p || p == buf) {
        old = "";
        p = buf + strlen(buf);
    }

    new_len = strlen(buf) - strlen(old) + strlen(new);
    if (new_len > len) p -= strlen(new) - strlen(old);

    strcpy(p, new);
}

FILE *prep_overall_file(char *path, int overwrite, int time)
{
    FILE *pfile;
    struct stat file_info;

    pfile = open_file(path, overwrite);
    stat(path, &file_info);
    if (file_info.st_size == 0) {
        fprintf(pfile, "subject%d\t", time);
        fprintf(pfile, "date%d_C\t", time);
        fprintf(pfile, "t%d_C\t", time);
        fprintf(pfile, "bias%d_C\t", time);
        fprintf(pfile, "rhkey%d_C\t", time);
        fprintf(pfile, "lnkey%d_C\t", time);
        fprintf(pfile, "strt%d_C\t", time);
        fprintf(pfile, "end_%d_C\t", time);
        fprintf(pfile, "vldtrl%d_C\t", time);
        fprintf(pfile, "rhct%d_C\t", time);
        fprintf(pfile, "lnct%d_C\t", time);
        fprintf(pfile, "corct%d_C\t", time);
        fprintf(pfile, "rhcor%d_C\t", time);
        fprintf(pfile, "lncor%d_C\t", time);
        fprintf(pfile, "rwdct%d_C\t", time);
        fprintf(pfile, "rhrwd%d_C\t", time);
        fprintf(pfile, "lnrwd%d_C\t", time);
        fprintf(pfile, "blthr%d_C\t", time);
        fprintf(pfile, "abthr%d_C\t", time);
        fprintf(pfile, "moout%d_C\t", time);
        fprintf(pfile, "out_%d_C\t", time);
        fprintf(pfile, "avT%d_C\t", time);
        fprintf(pfile, "avrhT%d_C\t", time);
        fprintf(pfile, "avlnT%d_C\t", time);
        fprintf(pfile, "minT%d_C\t", time);
        fprintf(pfile, "maxT%d_C\t", time);
        fprintf(pfile, "sdT%d_C\t", time);
        fprintf(pfile, "ac%d_C\t", time);
        fprintf(pfile, "rhac%d_C\t", time);
        fprintf(pfile, "lnac%d_C\t", time);
        fprintf(pfile, "RB_pure%d_C\t", time);
        fprintf(pfile, "RB_adjst_zeros%d_C\t", time);
        fprintf(pfile, "RB_adjst_all%d_C\t", time);
        fprintf(pfile, "dis_pure%d_C\t", time);
        fprintf(pfile, "dis_adjst_zeros%d_C\t", time);
        fprintf(pfile, "dis_adjst_all%d_C\n", time);
    }
    return pfile;
}

FILE *prep_overall_quick(char *path, int overwrite, int time)
{
    FILE *pfile;
    struct stat file_info;

    pfile = open_file(path, overwrite);
    stat(path, &file_info);
    if (file_info.st_size == 0) {
        fprintf(pfile, "subject%d\t", time);
        fprintf(pfile, "date%d_C\t", time);
        fprintf(pfile, "t%d_C\t", time);
        fprintf(pfile, "bias%d_C\t", time);
        fprintf(pfile, "rhkey%d_C\t", time);
        fprintf(pfile, "lnkey%d_C\t", time);
        fprintf(pfile, "avT%d_C\t", time);
        fprintf(pfile, "avrhT%d_C\t", time);
        fprintf(pfile, "avlnT%d_C\t", time);
        fprintf(pfile, "ac%d_C\t", time);
        fprintf(pfile, "rhac%d_C\t", time);
        fprintf(pfile, "lnac%d_C\t", time);
        fprintf(pfile, "RB_pure%d_C\t", time);
        fprintf(pfile, "RB_adjst_zeros%d_C\t", time);
        fprintf(pfile, "RB_adjst_all%d_C\t", time);
        fprintf(pfile, "dis_pure%d_C\t", time);
        fprintf(pfile, "dis_adjst_zeros%d_C\t", time);
        fprintf(pfile, "dis_adjst_all%d_C\n", time);
    }
    return pfile;
}

FILE *prep_split_file(char *path, int overwrite, int time, session_t *sess)
{
    FILE *pfile;
    struct stat file_info;
    char *name;
    int i;

    pfile = open_file(path, overwrite);
    stat(path, &file_info);
    if (file_info.st_size == 0) {
        fprintf(pfile, "\t\t\t\t\t\t");
        for (i = 0; i < sess->n_bl; i++) {
            fprintf(pfile, "Block %s"
                "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"
                "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t",
                sess->blocks[i].name);
        }
        fprintf(pfile, "\n");

        fprintf(pfile, "subject\t");
        fprintf(pfile, "date%d\t", time);
        fprintf(pfile, "t%d\t", time);
        fprintf(pfile, "bias%d\t", time);
        fprintf(pfile, "rhkey%d\t", time);
        fprintf(pfile, "lnkey%d\t", time);

        for (i = 0; i < sess->n_bl; i++) {
            name = sess->blocks[i].name;

            fprintf(pfile, "strt%d_%s\t", time, name);
            fprintf(pfile, "end_%d_%s\t", time, name);
            fprintf(pfile, "vldtrl%d_%s\t", time, name);
            fprintf(pfile, "rhct%d_%s\t", time, name);
            fprintf(pfile, "lnct%d_%s\t", time, name);
            fprintf(pfile, "corct%d_%s\t", time, name);
            fprintf(pfile, "rhcor%d_%s\t", time, name);
            fprintf(pfile, "lncor%d_%s\t", time, name);
            fprintf(pfile, "rwdct%d_%s\t", time, name);
            fprintf(pfile, "rhrwd%d_%s\t", time, name);
            fprintf(pfile, "lnrwd%d_%s\t", time, name);
            fprintf(pfile, "blthr%d_%s\t", time, name);
            fprintf(pfile, "abthr%d_%s\t", time, name);
            fprintf(pfile, "moout%d_%s\t", time, name);
            fprintf(pfile, "out_%d_%s\t", time, name);
            fprintf(pfile, "avT%d_%s\t", time, name);
            fprintf(pfile, "avrhT%d_%s\t", time, name);
            fprintf(pfile, "avlnT%d_%s\t", time, name);
            fprintf(pfile, "minT%d_%s\t", time, name);
            fprintf(pfile, "maxT%d_%s\t", time, name);
            fprintf(pfile, "sdT%d_%s\t", time, name);
            fprintf(pfile, "ac%d_%s\t", time, name);
            fprintf(pfile, "rhac%d_%s\t", time, name);
            fprintf(pfile, "lnac%d_%s\t", time, name);
            fprintf(pfile, "RB_pure%d_%s\t", time, name);
            fprintf(pfile, "RB_adjst_zeros%d_%s\t", time, name);
            fprintf(pfile, "RB_adjst_all%d_%s\t", time, name);
            fprintf(pfile, "dis_pure%d_%s\t", time, name);
            fprintf(pfile, "dis_adjst_zeros%d_%s\t", time, name);
            fprintf(pfile, "dis_adjst_all%d_%s\t", time, name);
        }
        fprintf(pfile, "\n");
    }
    return pfile;
}

FILE* prep_prob_file(char *path, int overwrite)
{
    FILE *pfile;
    struct stat file_info;

    pfile = open_file(path, overwrite);
    stat(path, &file_info);
    if (file_info.st_size == 0) {
        fprintf(pfile,
            "Subj_ID\t"
            "RF_den\t"
            "LF_den\t"
            "R_num\t"
            "L_num\t"
            "Den\t"
            /*"Prob_R\t"
            "Prob_L\t"
            "R_div_L\t"*/

            "RF_R_num\t"
            "RF_IN_num\t"
            "RF_RR_num\t"
            "RF_RL_num\t"
            "RF_LL_num\t"
            "RF_LR_num\t"
            "Prob_RF_R\t"
            "Prob_RF_IN\t"
            "Prob_RF_RR\t"
            "Prob_RF_RL\t"
            "Prob_RF_LL\t"
            "Prob_RF_LR\t"

            "LF_R_num\t"
            "LF_IN_num\t"
            "LF_RR_num\t"
            "LF_RL_num\t"
            "LF_LL_num\t"
            "LF_LR_num\t"
            "Prob_LF_R\t"
            "Prob_LF_IN\t"
            "Prob_LF_RR\t"
            "Prob_LF_RL\t"
            "Prob_LF_LL\t"
            "Prob_LF_LR\t"

            "RnF_R_num\t"
            "RnF_IN_num\t"
            "RnF_RR_num\t"
            "RnF_RL_num\t"
            "RnF_LL_num\t"
            "RnF_LR_num\t"
            "Prob_RnF_R\t"
            "Prob_RnF_IN\t"
            "Prob_RnF_RR\t"
            "Prob_RnF_RL\t"
            "Prob_RnF_LL\t"
            "Prob_RnF_LR\t"

            "LnF_R_num\t"
            "LnF_IN_num\t"
            "LnF_RR_num\t"
            "LnF_RL_num\t"
            "LnF_LL_num\t"
            "LnF_LR_num\t"
            "Prob_LnF_R\t"
            "Prob_LnF_IN\t"
            "Prob_LnF_RR\t"
            "Prob_LnF_RL\t"
            "Prob_LnF_LL\t"
            "Prob_LnF_LR\n");
    }
    return pfile;
}

char **genFilenames(int count, char *argv[], int *newcount, ArgRec *args)
{
    int ii, dircount, rawcount;
    //int jj, rc;
    //int subj_id, trial_cond, epoch_num;
    char **rawlist;
    struct dirent **entry;
    /* we allocate enough space for all the filenames, even though we
     * may not need them all */
    rawcount = 0;

    /* First, if the args.indir is set, then we open this directory and set
     * the filelist to be all of the contents. */

    if (strcmp(args->indir, "") != 0) {
        dircount = scandir(args->indir, &entry, 0, alphasort);
        rawlist = malloc(dircount * sizeof (char *));
        if (dircount < 0) {
            fprintf(stderr, "cannot input directory %s\n", args->indir);
            return NULL;
        } else if (dircount == 2) {
            fprintf(stderr, "The input directory %s is empty\n", args->indir);
            return NULL;
        } else {
            for (ii = 0; ii < dircount; ii++) {
                if (strcmp(entry[ii]->d_name, ".") == 0
                    || strcmp(entry[ii]->d_name, "..") == 0) {
                    continue;
                } else if (strstr(entry[ii]->d_name, ".xls") ==
                           entry[ii]->d_name + strlen(entry[ii]->d_name) -
                           4) {
                    continue;
                } else {
                    /*rawlist[rawcount] =
                      malloc(strlen(entry[ii]->d_name)+strlen(args->indir)+2);
                      strcpy(rawlist[rawcount], args->indir);
                      strcat(rawlist[rawcount], "/"); */
                    rawlist[rawcount] = malloc(strlen(entry[ii]->d_name) + 2);
                    strcpy(rawlist[rawcount], entry[ii]->d_name);
                    rawcount++;
                }
            }
        }
    } else {
        rawlist = malloc(count);
        for (ii = 0; ii < count; ii++) {
            if (strncmp(argv[ii], "-", 1) != 0) {
                rawlist[rawcount] = malloc((strlen(argv[ii]) + 2));
                strcpy(rawlist[rawcount], argv[ii]);
                rawcount++;
            }
        }
    }
    *newcount = rawcount;
    return rawlist;
}
