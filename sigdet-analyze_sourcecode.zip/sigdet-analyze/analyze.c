#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <dirent.h>

#include "sigdet.h"
#include "analyze.h"
#include "file.h"
#include "block.h"
#include "session.h"

int main(int argc, char *argv[])
{
    trial_t trials[TRIALS_MAX];
    session_t *sess, tmp_sess;
    block_t *main_block, *total_block, tmp_bl;

    char **rawlist;
    int offset, rt, rc;
    int i, j, n, len, nf;
    char input_line[BUF_MAX];
    size_t length;
    char *buffer, *b2r = NULL;
    char subj[BUF_MAX];
    char rich[10], did_reward[10], p[10];
    //char format[BUF_MAX];
    char date[BUF_MAX];
    char time[BUF_MAX];
    int raw_count;
    struct stat file_info;
    int files_processed;
    //int num_args;
    ArgRec args, save_args;
    enum header head_type;
    char buf[BUF_MAX];
    char input_file[BUF_MAX];

    int opened_over_files = 0;
    char over_path[BUF_MAX];
    char over_split_path[BUF_MAX];
    char over_quick_path[BUF_MAX];
    char over_sens_path[BUF_MAX];
    char smbl_sens_path[BUF_MAX];
    char over_prob_path[BUF_MAX];
    char sess_path[BUF_MAX];
    char outl_path[BUF_MAX];
    char sens_path[BUF_MAX];
    //char prob_path[BUF_MAX];
    FILE *sess_fd;
    FILE *over_fd;
    FILE *over_quick_fd;
    FILE *over_split_fd;
    FILE *over_sens_fd;
    FILE *smbl_sens_fd;
    FILE *over_prob_fd;
    FILE *outl_fd;
    FILE *sens_fd;
    //FILE *prob_fd;

    files_processed = 0;
    rc = getArgs(argc, argv, &args);
    if (rc != 0) exit(8);
    rawlist = genFilenames(argc, argv, &raw_count, &args);

    sprintf(outl_path, "%s/outliers.out", args.outdir);
    outl_fd = open_file(outl_path, args.overwrite);

    save_args = args;

    for (j = 0; j < raw_count; j++) {
        strcpy(input_file, rawlist[j]);

        snprintf(sess_path, sizeof sess_path,
            "%s/%s", args.outdir, input_file);
        change_ext(sess_path, sizeof sens_path,
            ".txt", ".out");
        snprintf(sens_path, sizeof sens_path,
            "%s/%s", args.outdir, input_file);
        change_ext(sens_path, sizeof sens_path,
            ".txt", ".sens");

        /* Now lets open the output file and the overall file */

        sess_fd = open_file(sess_path, args.overwrite);
        stat(sess_path, &file_info);
        if (file_info.st_size != 0 && !args.overwrite)
            continue;

        fprintf(stderr, "processing %s\n", input_file);

        /* Open indiv. sensitivity file for writing the cumulative sensitivity
         * calculations */

        sens_fd = open_file(sens_path, args.overwrite);

        /* First we read the file into a buffer */

        sprintf(input_file, "%s/%s", args.indir, rawlist[j]);
        rt = read_file(input_file, &length, &buffer);
        if (buffer == NULL)
            return (-1);

        /* Now figure out what type of file we have */

        if (args.header_type != HEAD_UNKNOWN)
            head_type = args.header_type;
        else
            head_type = identify_header(buffer);

        switch (head_type) {
            case HEAD_PSYSCOPE:
                offset = skip_lines(4, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "PsyScope 1.2.5 PPC started: %s %s", date,
                       time);
                offset = skip_lines(9, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "SubjectName: %s", subj);
                break;
            case HEAD_DCRP:
                offset = skip_lines(4, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "SigDet task DCRP started: %s %s", date,
                       time);
                offset = skip_lines(9, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "SubjectName: %s", subj);
                break;
            case HEAD_FT:
                offset = skip_lines(4, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "SigDet task FT started: %s %s", date,
                       time);
                offset = skip_lines(9, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "SubjectName: %s", subj);
                break;
            case HEAD_B2R:
                offset = skip_lines(1, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "%s %s %*s", date, time);
                offset = skip_lines(2, buffer);
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "Subject:%s", subj);
                offset = skip_lines(4, buffer);
                offset = read_line(buffer, offset, input_line);
                b2r = malloc(BUF_MAX);
                sscanf(input_line, "Block2Run:%s", b2r);
                break;
            case HEAD_REWGEO:
                strcpy(date, "None");
                strcpy(time, "None");
                strcpy(subj, "None");
                break;
            case HEAD_UNKNOWN:
                /* Skip the header up to the subject name */
                offset = skip_lines(1, buffer);
                /* Get date */
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "%s %s %*s", date, time);
                offset = skip_lines(2, buffer);
                /* Get subject name */
                offset = read_line(buffer, offset, input_line);
                sscanf(input_line, "Subject:%s", subj);
                offset = skip_lines(7, buffer);
                break;
        }

        /* print out the subject name for the sake of all our viewers out
         * there */

        fprintf(outl_fd, "Processing %s...\n", subj);

        /* for some reason we have to skip the entire header again (as opposed
         * to just the remainder). */
        if (head_type == HEAD_REWGEO)
            offset = 0;
        else if (head_type == HEAD_B2R)
            offset = skip_lines(15, buffer);
        else
            offset = skip_lines(16, buffer);
        offset = read_line(buffer, offset, input_line);

        if (!args.version) {
            if (strstr(input_line, "trial#\tlist"))
                args.version = 4;
            else if (strstr(input_line, "tasktype"))
                args.version = 3;
            else if (strstr(input_line, "mytrial"))
                args.version = 2;
            else
                args.version = 1;
        }

        if (head_type == HEAD_REWGEO)
            offset = skip_lines(1, buffer);
        else
            offset = skip_lines(16, buffer);

        /* Then we populate the records in our trial array with the data */

        for (i = n = 0; offset + 1 < length; ) {
            offset = read_line(buffer, offset, input_line);
            offset = skip_line(buffer, offset);

            strcpy(buf, "");
            sscanf(input_line, " %s", buf);
            if (strlen(buf) == 0 ||
                strncmp(buf, "-\r", 1) == 0 ||
                strncmp(buf, "-\n", 1) == 0 ||
                strncasecmp(buf, "trial", 5) == 0 ||
                strncasecmp(buf, "subject", 5) == 0)
                continue;

            /* okay, so it's a non-blank, non-header line. */

            n++;
            if (args.skip && (n >= 81 && n <= 84))
                continue;

            switch (args.version) {
                case 1:
                    nf = sscanf(input_line,
                        " %d %10s %d %c %*d %d %d %d %d %d",
                        &trials[i].n, trials[i].stimulus, &trials[i].rt,
                        &trials[i].key, &trials[i].correct,
                        &trials[i].feedback, &trials[i].due,
                        &trials[i].due_rich, &trials[i].due_lean);
                    if (nf < 9) continue;
                    if (!trials[i].rt) {
                        /* Time is not a number. It is probably N/A, so we
                         * need to reread that line and force it to be 0. */
                        nf = sscanf(input_line,
                            " %d %10s %*d %c %*d %d %d %d %d %d",
                            &trials[i].n, trials[i].stimulus, &trials[i].key,
                            &trials[i].correct, &trials[i].feedback,
                            &trials[i].due, &trials[i].due_rich,
                            &trials[i].due_lean);
                        trials[i].rt = 0;
                        if (nf < 8) continue;
                    }
                    break;
                case 2:
                    nf = sscanf(input_line, " %d %10s %d %c %d %d %d %d %d",
                        &trials[i].n, trials[i].stimulus, &trials[i].rt,
                        &trials[i].key, &trials[i].correct,
                        &trials[i].feedback, &trials[i].due,
                        &trials[i].due_rich, &trials[i].due_lean);
                    if (trials[i].rt == 0) {
                        /* this is a bug in the task. if they didn't respond
                         * at all, no RT is printed, and the key pressed (0
                         * indicating none) is in the third column. So we have
                         * to reread with the fields off by one. */
                        nf = sscanf(input_line, " %d %10s %c %d %d %d %d %d",
                            &trials[i].n, trials[i].stimulus, &trials[i].key,
                            &trials[i].correct, &trials[i].feedback,
                            &trials[i].due, &trials[i].due_rich,
                            &trials[i].due_lean);
                    } else if (nf < 9) continue;
                    break;
                case 3:
                    /* will need subj name later. just overwrite each time */
                    nf = sscanf(input_line,
                        " %10s %*d %d %10s %d %10s %d %10s", subj,
                        &trials[i].correct, rich, &trials[i].due,
                        did_reward, &trials[i].rt, trials[i].tasktype);
                    if (nf < 7 || strcmp(rich, "?") == 0)
                        continue;
                    trials[i].feedback = (strcmp(did_reward, "Feed") == 0);
                    trials[i].n = i + 1;
                    /* not true, but pick something arbitrary for now */
                    if (strcmp(rich, "rich") == 0)
                        strcpy(trials[i].stimulus, "Big");
                    else
                        strcpy(trials[i].stimulus, "Little");
                    break;
                case 4:
                    nf = sscanf(input_line,
                        " %d %*d %10s %d %d %*10s %d %d %d %*c %c",
                        &trials[i].n, trials[i].stimulus, &trials[i].correct,
                        &trials[i].rt, &trials[i].feedback, &trials[i].due,
                        &trials[i].due_rich, &trials[i].key);
                    if (nf == 7) trials[i].key = ' ';
                    else if (nf < 8) continue;
                    break;
            }

            /* we actually read something. */
            i++;
        }

        if (i == 0) {
            printf("skipping empty file...\n");
            continue;
        } else {
            len = i;
        }

        /* now that we know len we can check things */

        sess = alloc_session(trials, len, args.n_bl, args.blen, subj,
            date, time, b2r, args.lo_thresh, args.hi_thresh);

        if (!(args.sens_blen && len % args.sens_blen == 0)) {
            if (args.sens_blen)
                fprintf(stderr, "sens block size is %d; must be > 0 "
                    "and a divisor of %d (defaulting to 1/2 block size)\n",
                    args.sens_blen, len);
            args.sens_blen = sess->blen / 2;
        }

        if (args.sens_start_trial > len - 1) {
            fprintf(stderr, "sens start trial must be 0..%d\n", len - 1);
            fprintf(stderr, "defaulting to 0\n");
            args.sens_start_trial = 0;
        }

        if (args.prob_start_trial > len - 1) {
            fprintf(stderr, "sens start trial must be 0..%d\n", len - 1);
            fprintf(stderr, "defaulting to 0\n");
            args.prob_start_trial = 0;
        }

        for (i = 0; i < sess->n_real_bl; i++) {
            snprintf(buf, sizeof buf, "%d", i+1);
            init_block(&sess->blocks[i], sess, buf, i * sess->blen,
                sess->blen);
            if (args.split) {
                snprintf(buf, sizeof buf, "%da", i+1);
                add_block(sess, buf, i * sess->blen, sess->blen / 2);
                snprintf(buf, sizeof buf, "%db", i+1);
                add_block(sess, buf, i * sess->blen + sess->blen / 2,
                    sess->blen / 2);
            }
        }

        add_block(sess, "Main", sess->blen, sess->len - sess->blen);
        add_block(sess, "Total", 0, sess->len);

        /* done allocating memory, so we can take some pointers now */

        main_block = sess->blocks + sess->n_bl-2;
        total_block = sess->blocks + sess->n_bl-1;

        /* now that we know all those we can decide filenames */

        if (!opened_over_files) {
            sprintf(over_path, "%s/calcs_2-%d_comb.out", args.outdir,
                sess->n_real_bl);
            sprintf(over_split_path, "%s/calcs_1-%d_split.out", args.outdir,
                sess->n_real_bl);
            sprintf(over_quick_path, "%s/calcs_2-%d_quick.out", args.outdir,
                sess->n_real_bl);
            sprintf(smbl_sens_path, "%s/sens_by_blocks_%d.out", args.outdir,
                args.sens_blen);
            sprintf(over_sens_path, "%s/cumul_sens_%d-%d.out", args.outdir,
                args.sens_start_trial + 1, len);
            sprintf(over_prob_path, "%s/prob_%d-%d.out", args.outdir,
                args.prob_start_trial + 1, len);

            over_fd = prep_overall_file(over_path, args.overwrite, args.time);
            over_quick_fd = prep_overall_quick(over_quick_path, args.overwrite,
                args.time);
            over_split_fd = prep_split_file(over_split_path, args.overwrite,
                args.time, sess);
            over_prob_fd = prep_prob_file(over_prob_path, args.overwrite);

            /* Open and close the output files. We do this to truncate the
             * file in case the overwrite flag has been raised */

            over_sens_fd = open_file(over_sens_path, args.overwrite);
            smbl_sens_fd = open_file(smbl_sens_path, args.overwrite);
            fclose(over_sens_fd);
            fclose(smbl_sens_fd);

            opened_over_files = 1;
        }

        write_calcs_head(sess, over_fd);
        write_block_stats(main_block, over_fd);
        fprintf(over_fd, "\n");

        write_calcs_head(sess, over_split_fd);
        for (i = 0; i < sess->n_bl; i++)
            write_block_stats(&sess->blocks[i], over_split_fd);
        fprintf(over_split_fd, "\n");

        write_calcs_head(sess, over_quick_fd);
        write_block_quick(main_block, over_quick_fd);

        write_outliers(sess, outl_fd);

        write_sens(sess, args.sens_start_trial, sess->len -
            args.sens_start_trial, 1, 1, sens_fd, over_sens_path);
        write_sens(sess, args.sens_start_trial, sess->len -
            args.sens_start_trial, args.sens_blen, 0, NULL, smbl_sens_path);
        write_over_prob(sess, args.prob_start_trial, sess->len -
            args.prob_start_trial, over_prob_fd);

        write_preamble(sess, sess_fd);
        for (i = 0; i < sess->n_bl; i++) {
            write_block_summary(&sess->blocks[i], sess_fd);
            if (args.do_reverse) {
                tmp_sess = *sess;
                tmp_bl = sess->blocks[i];
                strncpy(p, tmp_sess.rich_name, sizeof p);
                strncpy(tmp_sess.rich_name, tmp_sess.lean_name,
                    sizeof tmp_sess.rich_name);
                strncpy(tmp_sess.lean_name, p, sizeof tmp_sess.lean_name);
                tmp_bl.session = &tmp_sess;
                tmp_bl.stats = init_stats(&tmp_bl);
                write_rev_summary(&tmp_bl, sess_fd);
            }
        }

        write_column_head(sess, sess_fd);
        write_trials(sess, sess_fd);

        files_processed++;
        args = save_args;
    }

    if (files_processed) {
        fclose(over_fd);
        fclose(sess_fd);
        fclose(sens_fd);
        fclose(over_split_fd);
        fclose(over_quick_fd);
    } else {
        fprintf(stderr, "No new files to process in %s.\n", args.indir);
    }

    free(b2r);
    for (i = 0; i < sess->n_bl; i++)
        free(sess->blocks[i].stats);
    free(sess->blocks);
    free(sess);

    return 0;
}

int getArgs(int argc, char *argv[], ArgRec *args)
{
    int i, mycount, badcount, fd;
    //int subj_id, trial_cond, epoch_num;
    //int init_subj;
    int firstfile;
    char **arglist;
    struct stat file_info;

    /* we allocate enough space for all the args, even though we
     * may not need them all */
    arglist = (char **) malloc(argc * sizeof *arglist);
    mycount = badcount = 0;
    firstfile = 0;

    /* defaults */
    strcpy(args->outdir, "./done");
    strcpy(args->indir, "./rawdata");
    args->n_bl = DEFAULT_BLOCKS;
    args->blen = 0;
    args->sens_blen = 0;
    args->sens_start_trial = 0;
    args->prob_start_trial = 0;
    args->help = 0;
    args->overwrite = 0;
    args->split = 0;
    args->do_reverse = 0;
    args->time = 1;
    args->version = 0;
    args->skip = 0;
    args->header_type = HEAD_UNKNOWN;
    args->lo_thresh = DEFAULT_LO_THRESH;
    args->hi_thresh = DEFAULT_HI_THRESH;

    for (i = 1; i < argc; i++) {
        if (argv[i][0] == '-') {
            if (strcmp(argv[i], "-?") == 0) {
                args->help = 1;
            } else if (strcmp(argv[i], "-i") == 0 && i + 1 < argc) {
                strcpy(args->indir, argv[++i]);
            } else if (strcmp(argv[i], "-o") == 0 && i + 1 < argc) {
                strcpy(args->outdir, argv[++i]);
            } else if (strcmp(argv[i], "-f") == 0) {
                args->overwrite = 1;
            } else if (strcmp(argv[i], "-b") == 0 && i + 1 < argc) {
                args->n_bl = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-n") == 0 && i + 1 < argc) {
                args->blen = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-sb") == 0 && i + 1 < argc) {
                args->sens_blen = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-st") == 0 && i + 1 < argc) {
                args->sens_start_trial = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-pt") == 0 && i + 1 < argc) {
                args->prob_start_trial = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-x") == 0) {
                args->split = 1;
            } else if (strcmp(argv[i], "-r") == 0) {
                args->do_reverse = 1;
            } else if (strcmp(argv[i], "-s") == 0) {
                args->skip = 1;
            } else if (strcmp(argv[i], "-t") == 0) {
                args->time = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-v") == 0) {
                args->version = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-h") == 0 && i + 1 < argc) {
                args->header_type = identify_header_line(argv[++i]);
            } else if (strcmp(argv[i], "-l") == 0) {
                args->lo_thresh = atoi(argv[++i]);
            } else if (strcmp(argv[i], "-u") == 0) {
                args->hi_thresh = atoi(argv[++i]);
            } else {
                /* unknown flag */
                fprintf(stderr, "Ignoring unknown flag %s\n", argv[i]);
            }
        }
    }

    if (args->help == 1) {
        fprintf(stderr,
            "Reward Analyze Help Message\n"
            "Command line arguments:\n"
            "  -i <DIR>\tinput directory (default: rawdata)\n"
            "  -o <DIR>\toutput directory (default: done)\n"
            "  -f\t\toverwrite existing output files\n"
            "  -b <NUM>\tnumber of blocks (default: 3)\n"
            "  -n <NUM>\texplicit block size (default: trials/blocks)\n"
            "  -l\t\tlower threshold for discarding response times\n"
            "  -u\t\tupper threshold for discarding response times\n"
            "  -x\t\tsplit blocks in half and calculate each separately\n"
            "  -sb <NUM>\tblock size for sens_by_block (default: block/2)\n"
            "  -st <NUM>\tstart trial for cumulative RB (cumul_sens_x-y.out)\n"
                "\t\t(default: 0)\n"
            "  -sp <NUM>\tstart trial for probability stats (prob_x-y.out)\n"
                "\t\t(default: 0)\n"
            "  -s\t\tskip trials 81-84\n"
            "  -r\t\treverse lean and rich stimuli\n"
            "  -v <1-4>\tspecify version of input data (default: guess)\n"
            "  -h <HEAD>\tspecify header (default: guess)\n"
            "  -t <1-2>\tspecify time 1 or time 2 (default: 1)\n"
            "  -?\t\tprint this help message\n");
        return -1;
    }

    fd = open(args->indir, O_RDONLY);
    if (fd == -1) {
        fprintf(stderr, "Specified input directory %s does not exist\n",
                args->indir);
        return (-1);
    } else {
        /* Get information about the file. */
        fstat(fd, &file_info);
        /* Make sure the file is a directory. */
        if (!S_ISDIR(file_info.st_mode)) {
            /* It's not, so give up. */
            fprintf(stderr, "Specified directory %s is not a directory\n",
                    args->indir);
            return (-1);
        }
        close(fd);
    }

    fd = open(args->outdir, O_RDONLY);
    if (fd == -1) {
        mkdir(args->outdir, 0777);
    } else {
        /* Get information about the file. */
        fstat(fd, &file_info);
        /* Make sure the file is a directory. */
        if (!S_ISDIR(file_info.st_mode)) {
            /* It's not, so give up. */
            fprintf(stderr, "Specified directory %s is not a directory\n",
                    args->outdir);
            return (-1);
        }
        close(fd);
    }

    if ((args->time != 1) && (args->time != 2)) {
        fprintf(stderr, "-t (time) must be 1 or 2\n");
        fprintf(stderr, "defaulting to 1\n");
        args->time = 1;
    }

    free(arglist);
    return mycount;
}
