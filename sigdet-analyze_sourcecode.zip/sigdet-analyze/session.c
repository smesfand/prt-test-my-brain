#include "sigdet.h"
#include "file.h"
#include "session.h"
#include "block.h"

session_t *alloc_session(trial_t *trials, size_t len, size_t n_bl,
    size_t blen, char *subj, char *date, char *time, char *b2r, int lo_thresh,
    int hi_thresh)
{
    session_t *self = malloc(sizeof *self);

    self->trials = trials;
    self->len = len;

    if (blen > 0) {
        self->blen = blen;
        self->n_bl = len / blen;
    } else {
        self->n_bl = n_bl;
        self->blen = len / n_bl;
    }

    if (self->blen < 1) {
        fprintf(stderr, "Block size is less than 1, aborting...\n");
        exit(6);
    }

    self->n_real_bl = self->n_bl;
    self->blocks = malloc(self->n_bl * sizeof *self->blocks);

    strncpy(self->subj, subj, sizeof self->subj);
    strncpy(self->date, date, sizeof self->date);
    strncpy(self->time, time, sizeof self->time);

    self->head_type = HEAD_UNKNOWN;
    if (b2r) init_bias_b2r(self, b2r);
    else init_bias(self);

    self->lo_thresh = lo_thresh;
    self->hi_thresh = hi_thresh;

    flag_outliers(self);

    return self;
}

void init_bias(session_t *sess)
{
    /* should have a hash table or something */
    int i, n_long = 0, n_short = 0, n_big = 0, n_little = 0;
    trial_t t;

    sess->l_key = 0;
    sess->r_key = 0;

    for (i = 0; i < sess->len; i++) {
        t = sess->trials[i];
        if (strcasecmp(t.stimulus, "long") == 0 && t.correct && t.feedback)
            n_long++;
        if (strcasecmp(t.stimulus, "short") == 0 && t.correct && t.feedback)
            n_short++;
        if (strcasecmp(t.stimulus, "big") == 0 && t.correct && t.feedback)
            n_big++;
        if (strcasecmp(t.stimulus, "little") == 0 && t.correct && t.feedback)
            n_little++;
    }

    if (n_big == 0 && n_little == 0) {
        if (n_long > n_short) {
            strncpy(sess->rich_name, "long", sizeof sess->rich_name);
            strncpy(sess->lean_name, "short", sizeof sess->lean_name);
            sess->bias = LONG;
        } else {
            strncpy(sess->rich_name, "short", sizeof sess->rich_name);
            strncpy(sess->lean_name, "long", sizeof sess->lean_name);
            sess->bias = SHORT;
        }
    } else if (n_long == 0 && n_short == 0) {
        if (n_big > n_little) {
            strncpy(sess->rich_name, "big", sizeof sess->rich_name);
            strncpy(sess->lean_name, "little", sizeof sess->lean_name);
            sess->bias = BIG;
        } else {
            strncpy(sess->rich_name, "little", sizeof sess->rich_name);
            strncpy(sess->rich_name, "big", sizeof sess->rich_name);
            sess->bias = LITTLE;
        }
    } else {
        fprintf(stderr, "error, more than two stimuli detected\n");
        fprintf(stderr, "we only handle short/long or big/little\n");
        sess->bias = UNKNOWN;
    }

    for (i = 0; i < sess->len && (!sess->r_key || !sess->l_key); i++) {
        if (is_rich(sess, sess->trials[i])) {
            if (sess->trials[i].correct)
                sess->r_key = sess->trials[i].key;
            else
                sess->l_key = sess->trials[i].key;
        } else if (is_lean(sess, sess->trials[i])) {
            if (sess->trials[i].correct)
                sess->l_key = sess->trials[i].key;
            else
                sess->r_key = sess->trials[i].key;
        }
    }
}

void init_bias_b2r(session_t *sess, const char *b2r)
{
    sess->l_key = 0;
    sess->r_key = 0;

    if (b2r[0] == 'L') {
        /* Long, i.e. big mouth */
        strncpy(sess->rich_name, "big", sizeof sess->rich_name);
        strncpy(sess->lean_name, "little", sizeof sess->lean_name);
        sess->bias = BIG;
    } else {
        /* Short, i.e. little mouth */
        strncpy(sess->rich_name, "little", sizeof sess->rich_name);
        strncpy(sess->lean_name, "big", sizeof sess->lean_name);
        sess->bias = LITTLE;
    }

    /* if (b2r[1] == 'M')
         StimType is mouth
     else / * == 'N' * /
         StimType is nose */

    if (b2r[2] == '1') {
        sess->l_key = '1';
        sess->r_key = '4';
    } else {
        sess->l_key = '4';
        sess->r_key = '1';
    }

    /* if (strcmp(b2r+3, "Safe") == 0) {
        Condition is Safe
    } else if (strcmp(b2r+3, "Stress") == 0) {
        Condition is Stress
    } else */ if (strcmp(b2r+3, "v") == 0) {
        sess->l_key = 'v';
        sess->r_key = 'm';
    }
}

void flag_outliers(session_t *sess)
{
    double stdev, mean, diff = 0, sum = 0;
    int i, n = 0;

    for (i = 0; i < sess->len; i++)
        sess->trials[i].out = NOT_OUT;

    for (i = 0; i < sess->len; i++)
        if (sess->trials[i].rt < sess->lo_thresh)
            sess->trials[i].out = OUT_BELOW;
        else if (sess->trials[i].rt > sess->hi_thresh)
            sess->trials[i].out = OUT_ABOVE;

    for (i = 0; i < sess->len; i++) {
        if (!sess->trials[i].out) {
            sum += log(sess->trials[i].rt);
            n++;
        }
    }
    mean = sum / n;

    for (i = 0; i < sess->len; i++)
        if (!sess->trials[i].out)
            diff += pow(log(sess->trials[i].rt) - mean, 2);
    stdev = sqrt(diff / (n - 1));

    for (i = 0; i < sess->len; i++) {
        if (fabs(mean - log(sess->trials[i].rt)) > 3 * stdev) {
            if (!sess->trials[i].out)
                sess->trials[i].out = OUT_STDEV;
        }
    }
}

int is_rich(session_t *sess, trial_t t)
{
    return strcasecmp(sess->rich_name, t.stimulus) == 0;
}

int is_lean(session_t *sess, trial_t t)
{
    return strcasecmp(sess->lean_name, t.stimulus) == 0;
}

void write_column_head(session_t *sess, FILE *out)
{
    fprintf(out, "\n\ntrial\tlength\ttime\tkey_press\tcorrect\t"
        "did_reward\treward_due\trich_due\tlean_due\toutlier\n");
}

void write_trials(session_t *sess, FILE *out)
{
    trial_t t;
    int i;

    for (i = 0; i < sess->len; i++) {
        t = sess->trials[i];
        fprintf(out, "%d\t%s\t%d\t%c\t%d\t%d\t%d\t%d\t%d\t%d\n",
            t.n, t.stimulus, t.rt, t.key ? t.key : '?', t.correct, t.feedback,
            t.due, t.due_rich, t.due_lean, sess->trials[i].out != NOT_OUT);
    }
}

void write_preamble(session_t *sess, FILE *out)
{
    fprintf(out, "Subject ID: %s\n", sess->subj);
    fprintf(out, "Date: %s\n", sess->date);
    fprintf(out, "Time: %s\n", sess->time);
    fprintf(out, "Bias: %s\n", BIAS_TO_S(sess->bias));
    fprintf(out, "Rich stimulus: %s\n", sess->rich_name);
    fprintf(out, "Lean stimulus: %s\n", sess->lean_name);
    if (sess->r_key)
        fprintf(out, "Rich key: %c\n", sess->r_key);
    if (sess->l_key)
        fprintf(out, "Lean key: %c\n", sess->l_key);
}

void write_calcs_head(session_t *sess, FILE *out)
{
    fprintf(out, "%s\t%s\t%s\t%s\t%c\t%c\t", sess->subj, sess->date,
        sess->time, BIAS_TO_S(sess->bias), sess->r_key, sess->l_key);
}

void write_outliers(session_t *sess, FILE *out)
{
    int i, n_thresh = 0, n_stdev = 0;

    for (i = 0; i < sess->len; i++)
        if (sess->trials[i].out == OUT_ABOVE || sess->trials[i].out == OUT_BELOW)
            n_thresh++;
    for (i = 0; i < sess->len; i++)
        if (sess->trials[i].out == OUT_STDEV)
            n_stdev++;

    if (n_thresh) {
        fprintf(out, "\tThere are %d out of threshold range (%d-%dms):\n",
            n_thresh, sess->lo_thresh, sess->hi_thresh);
        for (i = 0; i < sess->len; i++)
            if (sess->trials[i].out == OUT_ABOVE || sess->trials[i].out == OUT_BELOW)
                fprintf(out, "\tTrial %d (%dms)\n", i+1, sess->trials[i].rt);
    }
    if (n_stdev) {
        fprintf(out, "\tThere are %d greater than 3 stdevs from mean:\n",
            n_stdev);
        for (i = 0; i < sess->len; i++)
            if (sess->trials[i].out == OUT_STDEV)
                fprintf(out, "\tTrial %d (%dms)\n", i+1, sess->trials[i].rt);
    }
}

void write_over_prob(session_t *sess, size_t start, size_t len, FILE *out)
{
    int i;
    trial_t *t;

    int r_count = 0;
    int l_count = 0;
    int r_rew_count = 0;
    int l_rew_count = 0;
    int r_no_count = 0;
    int l_no_count = 0;

    int rf_r_count = 0;
    int rf_in_count = 0;
    int rf_rr_count = 0;
    int rf_rl_count = 0;
    int rf_ll_count = 0;
    int rf_lr_count = 0;

    int lf_r_count = 0;
    int lf_in_count = 0;
    int lf_rr_count = 0;
    int lf_rl_count = 0;
    int lf_ll_count = 0;
    int lf_lr_count = 0;

    int rn_r_count = 0;
    int rn_in_count = 0;
    int rn_rr_count = 0;
    int rn_rl_count = 0;
    int rn_ll_count = 0;
    int rn_lr_count = 0;

    int ln_r_count = 0;
    int ln_in_count = 0;
    int ln_rr_count = 0;
    int ln_rl_count = 0;
    int ln_ll_count = 0;
    int ln_lr_count = 0;

    t = sess->trials;
    for (i = start; i < len; i++) {
        /* this part goes for all i */
        if ((is_rich(sess, t[i]) && t[i].correct) || (is_lean(sess, t[i]) && !t[i].correct))
            r_count++;
        else
            l_count++;
        /* bail... the test in the for() is just there for posterity */
        if (i >= len)
            break;
        /* now we can continue and check i+1. i will only go from 0..len-1.
         * test not just if i+1 was an outlier, but if i was, since that
         * throws our hypothesis (i+1 is influenced by i) out the window. */
        if (sess->trials[i].out || sess->trials[i+1].out)
            continue;
        if (is_rich(sess, t[i]) && t[i].feedback) {
            r_rew_count++;
            if (!t[i+1].correct) rf_in_count++;
            if (is_rich(sess, t[i+1]) &&  t[i+1].correct) rf_rr_count++;
            if (is_rich(sess, t[i+1]) && !t[i+1].correct) rf_rl_count++;
            if (is_lean(sess, t[i+1]) &&  t[i+1].correct) rf_ll_count++;
            if (is_lean(sess, t[i+1]) && !t[i+1].correct) rf_lr_count++;
        } else if (is_lean(sess, t[i]) && t[i].feedback) {
            l_rew_count++;
            if (!t[i+1].correct) lf_in_count++;
            if (is_rich(sess, t[i+1]) &&  t[i+1].correct) lf_rr_count++;
            if (is_rich(sess, t[i+1]) && !t[i+1].correct) lf_rl_count++;
            if (is_lean(sess, t[i+1]) &&  t[i+1].correct) lf_ll_count++;
            if (is_lean(sess, t[i+1]) && !t[i+1].correct) lf_lr_count++;
        }
        if (is_rich(sess, t[i]) && t[i].correct && !t[i].feedback) {
            r_no_count++;
            if (!t[i+1].correct) rn_in_count++;
            if (is_rich(sess, t[i+1]) &&  t[i+1].correct) rn_rr_count++;
            if (is_rich(sess, t[i+1]) && !t[i+1].correct) rn_rl_count++;
            if (is_lean(sess, t[i+1]) &&  t[i+1].correct) rn_ll_count++;
            if (is_lean(sess, t[i+1]) && !t[i+1].correct) rn_lr_count++;
        } else if (is_lean(sess, t[i]) && t[i].correct && !t[i].feedback) {
            l_no_count++;
            if (!t[i+1].correct) ln_in_count++;
            if (is_rich(sess, t[i+1]) &&  t[i+1].correct) ln_rr_count++;
            if (is_rich(sess, t[i+1]) && !t[i+1].correct) ln_rl_count++;
            if (is_lean(sess, t[i+1]) &&  t[i+1].correct) ln_ll_count++;
            if (is_lean(sess, t[i+1]) && !t[i+1].correct) ln_lr_count++;
        }
    }

    rf_r_count = rf_rr_count + rf_lr_count;
    lf_r_count = lf_rr_count + lf_lr_count;
    rn_r_count = rn_rr_count + rn_lr_count;
    ln_r_count = ln_rr_count + ln_lr_count;

    fprintf(out, "%s\t", sess->subj);
    fprintf(out, "%d\t", r_rew_count);
    fprintf(out, "%d\t", l_rew_count);
    fprintf(out, "%d\t", r_count);
    fprintf(out, "%d\t", l_count);
    fprintf(out, "%d\t", (int)sess->len);
    /*fprintf(out, "%f\t", r_count / (double) len);
      fprintf(out, "%f\t", l_count / (double) len);
      fprintf(out, "%f\t", r_count / (double) l_count);*/

    fprintf(out, "%d\t", rf_r_count);
    fprintf(out, "%d\t", rf_in_count);
    fprintf(out, "%d\t", rf_rr_count);
    fprintf(out, "%d\t", rf_rl_count);
    fprintf(out, "%d\t", rf_ll_count);
    fprintf(out, "%d\t", rf_lr_count);
    fprintf(out, "%f\t", rf_r_count / (double) r_rew_count);
    fprintf(out, "%f\t", rf_in_count / (double) r_rew_count);
    fprintf(out, "%f\t", rf_rr_count / (double) (rf_rr_count+rf_rl_count));
    fprintf(out, "%f\t", rf_rl_count / (double) (rf_rr_count+rf_rl_count));
    fprintf(out, "%f\t", rf_ll_count / (double) (rf_ll_count+rf_lr_count));
    fprintf(out, "%f\t", rf_lr_count / (double) (rf_ll_count+rf_lr_count));

    fprintf(out, "%d\t", lf_r_count);
    fprintf(out, "%d\t", lf_in_count);
    fprintf(out, "%d\t", lf_rr_count);
    fprintf(out, "%d\t", lf_rl_count);
    fprintf(out, "%d\t", lf_ll_count);
    fprintf(out, "%d\t", lf_lr_count);
    fprintf(out, "%f\t", lf_r_count / (double) l_rew_count);
    fprintf(out, "%f\t", lf_in_count / (double) r_rew_count);
    fprintf(out, "%f\t", lf_rr_count / (double) (lf_rr_count+lf_rl_count));
    fprintf(out, "%f\t", lf_rl_count / (double) (lf_rr_count+lf_rl_count));
    fprintf(out, "%f\t", lf_ll_count / (double) (lf_ll_count+lf_lr_count));
    fprintf(out, "%f\t", lf_lr_count / (double) (lf_ll_count+lf_lr_count));

    fprintf(out, "%d\t", rn_r_count);
    fprintf(out, "%d\t", rn_in_count);
    fprintf(out, "%d\t", rn_rr_count);
    fprintf(out, "%d\t", rn_rl_count);
    fprintf(out, "%d\t", rn_ll_count);
    fprintf(out, "%d\t", rn_lr_count);
    fprintf(out, "%f\t", rn_r_count / (double) r_no_count);
    fprintf(out, "%f\t", rn_in_count / (double) r_no_count);
    fprintf(out, "%f\t", rn_rr_count / (double) (rn_rr_count+rn_rl_count));
    fprintf(out, "%f\t", rn_rl_count / (double) (rn_rr_count+rn_rl_count));
    fprintf(out, "%f\t", rn_ll_count / (double) (rn_ll_count+rn_lr_count));
    fprintf(out, "%f\t", rn_lr_count / (double) (rn_ll_count+rn_lr_count));

    fprintf(out, "%d\t", ln_r_count);
    fprintf(out, "%d\t", ln_in_count);
    fprintf(out, "%d\t", ln_rr_count);
    fprintf(out, "%d\t", ln_rl_count);
    fprintf(out, "%d\t", ln_ll_count);
    fprintf(out, "%d\t", ln_lr_count);
    fprintf(out, "%f\t", ln_r_count / (double) l_no_count);
    fprintf(out, "%f\t", ln_in_count / (double) l_no_count);
    fprintf(out, "%f\t", ln_rr_count / (double) (ln_rr_count+ln_rl_count));
    fprintf(out, "%f\t", ln_rl_count / (double) (ln_rr_count+ln_rl_count));
    fprintf(out, "%f\t", ln_ll_count / (double) (ln_ll_count+ln_lr_count));
    fprintf(out, "%f\n", ln_lr_count / (double) (ln_ll_count+ln_lr_count));
}

void write_sens(session_t *sess, size_t start, size_t len, size_t chunk,
    int cumulative, FILE *out, char *over_path)
{
    int i;
    char line[4096];
    char tmpname[1024];
    char *p;
    FILE *tmpfile = NULL;
    FILE *over_fd;
    block_t *bl;

    over_fd = open_file(over_path, 0); // hackover
    fseek(over_fd, 0, SEEK_SET);

    if (fgets(line, sizeof line, over_fd)) {
        strcpy(tmpname, "_tmp_XXXXXX");
        tmpfile = fdopen(mkstemp(tmpname), "w+");
        if ((p = index(line, '\n')))
            *p = '\0';
        fprintf(tmpfile, "%s\t%s\n", line, sess->subj);
    } else {
        fprintf(over_fd, "%s\n", sess->subj);
    }

    for (i = 0; i < len; i += chunk) {
        if (cumulative)
            bl = alloc_block(sess, "", start, i+1);
        else
            bl = alloc_block(sess, "", i, chunk);

        if (out) {
            if (finite(bl->stats->sensitivity1))
                fprintf(out, "%0.8f\n", bl->stats->sensitivity1);
            else
                fprintf(out, "0\n");
        }

        if (fgets(line, sizeof line, over_fd)) {
            if ((p = index(line, '\n')))
                *p = '\0';
            if (finite(bl->stats->sensitivity1))
                fprintf(tmpfile, "%s\t%0.8f\n", line, bl->stats->sensitivity1);
            else
                fprintf(tmpfile, "%s\t0\n", line);
        } else {
            if (finite(bl->stats->sensitivity1))
                fprintf(over_fd, "%0.8f\n", bl->stats->sensitivity1);
            else
                fprintf(over_fd, "0\n");
        }

        fflush(over_fd);
        free(bl);
    }

    if (tmpfile) {
        fclose(tmpfile);
        rename(tmpname, over_path);
        remove(tmpname);
    }
    chmod(over_path, 0660);
}
