#ifndef FILE_H
#define FILE_H

/* file.c */
FILE *open_file(char *path, int overwrite);
int read_file(const char *filename, size_t *length, char **buffer);
int skip_line(char *buffer, int offset);
int read_line(char *buffer, int offset, char *line);
enum header identify_header(char *buffer);
enum header identify_header_line(char *s);
int skip_lines(int num, char *buffer);
enum stimulus get_stim_type(const char *s);
void get_bias_name(enum stimulus bias, char *bias_name);
void print_bias(enum stimulus bias, FILE *outf);
void get_timedate(char *buffer, char *date, char *time);
void change_ext(char *buf, size_t len, const char *old, const char *new);
FILE *prep_overall_file(char *path, int overwrite, int time);
FILE *prep_overall_quick(char *path, int overwrite, int time);
FILE *prep_split_file(char *path, int overwrite, int time, session_t *sess);
FILE* prep_prob_file(char *path, int overwrite);
char **genFilenames(int count, char *argv[], int *newcount, ArgRec *args);

#endif /* FILE_H */
